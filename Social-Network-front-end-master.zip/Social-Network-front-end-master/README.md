Hoosier Connection:
A social network for the students by the students
